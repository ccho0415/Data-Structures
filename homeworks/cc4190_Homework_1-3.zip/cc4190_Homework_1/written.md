### Weiss Exercise 2.1
 ###### Order the following functions by growth rate: 
 ###### N, N^1/2, N^1.5, N^2, NlogN, Nloglog N, N log^2 N, N log(N2), 2/N, 2^N, 2^(N/2), 37, N^2 log N, N^3. 
 ###### Indicate which functions grow at the same rate.
```html    
1. 2/N
2. 37
3. N^1/2
4. N
5. NloglogN
6. NlogN
7. Nlog(N^2)
8. Nlog^2 N
9. N^1.5
10. N^2
11. N^2 logN
12. N^3
13. 2^(N/2)
14. 2^N
```    
We can rewrite Nlog(N^2) to be 2NlogN. If we ignore the constant 2 in 2NlogN, then it will be the same as NlogN.

NlogN and Nlog(N^2) grow at the same rate.


---

### Weiss Exercise 2.6
######  In a recent court case, a judge cited a city for contempt and ordered a fine of $2 for the first day. 
######  Each subsequent day, until the city followed the judge’s order, the fine was squared (that is, the fine progressed as follows: $2, $4, $16, $256, $65, 536, . . .). 
######  a. What would be the fine on day N?

The fine on day N would be 
```html
fine = 2^(2^(n-1))
```
######  b. How many days would it take the fine to reach D dollars? (A Big-Oh answer will do.)
Here we abbreviate log base 2 as lg.
Here we represent the number of days as n.
If we set D dollars equal to the fine we get:
```html 
D = 2^(2^(n-1))
lg(D) = lg(2^(2^(n-1)))
lg(D) = 2^(n-1)
lg(lg(D)) = n-1
lg(lg(D)) + 1 = n
```

---

### Give an analysis of the Big-Oh running time for each of the following program fragments: 

a.
```java
int sum = 0;
for ( int i = 0; i < 23; i ++)
    for ( int j = 0; j < n ; j ++)
        sum = sum + 1;
```
O(N)
b.
```java
int sum = 0;
for ( int i = 0; i < n ; i ++)
    for ( int k = i ; k < n ; k ++)
        sum = sum + 1;
```
O(N^2)
c.
```java
public int foo(int n, int k) {
    if(n<=k)
        return 1;
    else
        return foo(n/k,k) + 1;
}
```
O(log(with base k) n) 

---
### Weiss 2.11
#### An algorithm takes 0.5 ms for input size 100. How long will it take for input size
#### 500 if the running time is the following (assume low-order terms are negligible):

Assuming that the computation time per step does not change between 100 steps and 500 steps.
We will assume that it takes around 0.005 ms.

a. linear
    O(N)
    500 * 0.005
    **2.5 ms** 
b. O(N logN)
    500*log(500) * 0.005
    **6.7474 ms** 
c. quadratic
    (500^2) * 0.005 
    **1,250 ms** 
d. cubic
    (500^3) * 0.005
    **625,000 ms** 

---

### Weiss 2.15
#### Give an efficient algorithm to determine if there exists an integer i such that Ai = i
#### in an array of integers A1 < A2 < A3 < ··· < AN. What is the running time of
#### your algorithm?


I would use a binary search algorithm. It would have the running time of O(log N)


```java    
    binarySearch(Arr, Ai){
        int start = 0;
        int end = Arr.length - 1;
        if(start != end){
            return search(Arr, Ai, start, end );
        }else{
            return -1;      
        }    
                
    }

    search(Arr, Ai, start,  end){
        int mid = (start+end)/2;
        if(Arr[mid].compareTo(Ai)<0){
            start = mid +1;
            return search(Arr, Ai, start, end );
        }else if(Arr[mid].compareTo(Ai)>0){
            end = mid-1;
            return search(Arr, Ai, start, end);
        }else{
            return mid;
        }  
    }
```