//-------------------------------
// Christine Chong cc4190
// Problem1.java
// Printing out the Max Perimeter from
// an Array of Rectangles
//-------------------------------
public class Problem1{
    
    // Method for Finding the Max Perimeter using compareTo     
    public static <AnyType extends Comparable<AnyType>>  
      AnyType findMax(AnyType[] arr) {
        int maxIndex = 0;
        for (int i = 1; i < arr.length; i++)
            if ( arr[i].compareTo(arr[maxIndex]) > 0 )
                maxIndex = i;
        return arr[maxIndex];
    } 
     
    // Main Method with a hard coded Rectangle array     
    public static void main(String[] args){
        Rectangle tangle1 = new Rectangle(5, 7);
        Rectangle tangle2 = new Rectangle( 3, 4);
        Rectangle tangle3 = new Rectangle(9, 10);
        Rectangle tangle4 = new Rectangle(10, 9);
        Rectangle[] arr = new Rectangle[4];
        arr[0] = tangle1;
        arr[1] = tangle2;
        arr[2] = tangle3;
        arr[3] = tangle4;
        Rectangle largest = Problem1.findMax(arr);
        System.out.println("The Largest Perimeter is "
                           +Rectangle.getPerimeter(largest)+
                           " units \n The Width is : "+ 
                          Rectangle.getWidth(largest)+". \n"+
                          "The Height is : "+ Rectangle.getLength(largest)+".");
    }    
}
