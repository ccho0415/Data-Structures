//-------------------------------
// Christine Chong cc4190
// Problem2.java
// Using Binary Search to Find the index of 
// an Rectangle Object
//-------------------------------
public class Problem2{     
    
    // Main Method with a hard coded Rectangle array     
    public static void main(String[] args){
        Rectangle tangle2 = new Rectangle(5, 7);
        Rectangle tangle1 = new Rectangle(3, 4);
        Rectangle tangle3 = new Rectangle(9, 10);
        Rectangle tangle4 = new Rectangle(10, 10);
        Rectangle[] arr = new Rectangle[3];
        arr[0] = tangle1;
        arr[1] = tangle2;
        arr[2] = tangle3;
        int idx = Problem2.binarySearch(arr, tangle2);
        if(idx == -1){
            System.out.println("Not a part of this array");
        }else{
            System.out.println("It is at index: "+idx);       
        }
              
    } 
    
    // Driver Method with a Helper Method     
    public static <AnyType extends Comparable<AnyType>> int binarySearch(AnyType[] a, AnyType x){
        int start = 0;
        int end = a.length-1;
        return search(a, x, start, end );            
                
    }

    // Recursive Helper Method for binarySearch      
    private static <AnyType extends Comparable<AnyType>> int search(AnyType[] a, AnyType x, int start, int end){
        if(end < start){
            return -1; 
        }      
        int mid = (start+end)/2;
        if(a[mid].compareTo(x)<0){
            start = mid +1;
            return search(a, x, start, end );
        }else if(a[mid].compareTo(x)>0){
            end = mid-1;
            return search(a, x, start, end);
        }else{
            return mid;
        } 
    }
}
