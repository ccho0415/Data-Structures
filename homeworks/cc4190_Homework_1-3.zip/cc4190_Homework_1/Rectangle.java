//-------------------------------
// Christine Chong cc4190
// Rectangle.java
// Properties of a Rectangle Object
//-------------------------------
public class Rectangle implements Comparable<Rectangle> {
    
    //Variables    
    private int l;
    private int w;
    private int perimeter;
    
    // Constructor     
    public Rectangle (int l, int w ){
        this.l = l;
        this.w = w;
        this.perimeter = (2*w)+(2*l);
    }
    
    // Method to return the length     
    public static int getLength(Rectangle a){
        return(a.l);   
    }   
    
    // Method to return the width
    public static int getWidth(Rectangle a){
        return(a.w);    
    }
    
    // Method to return the perimeter
    public static int getPerimeter(Rectangle a){
        return(a.perimeter);
    }
    
    // Method to compare the perimeters
    public int compareTo (Rectangle other){
        Integer p1 = new Integer(this.perimeter);
        Integer p2 = new Integer(other.perimeter);        
        return (p1.compareTo(p2));
    } 
    
}