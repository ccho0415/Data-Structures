//-------------------------------
// Christine Chong cc4190
// README.txt
//-------------------------------
Problem1.java
    For the findMax method, I used the one provided in the prompt without changing it
    For the main method I hardcoded in some Rectangles with various sizes and 2 Rectangles with the same perimeter.
        The method will only print out the first Rectangle with the largest perimeter. It will not print out the
        second rectangle with the largets perimeter as it does not meet the condition to replace the maxIndex. (On line 9);
Rectangle.java
    I implemeneted the Comparable Interface so that I can use .compareTo on the perimeters of the rectangles.
    I set up some variables and a constructor to create Rectangle Objects.
    The getLength, getWidth and getPerimeter methods return the value requested that belongs to the Rectangle that
        is passed in explicitly when the method is called.
    The compareTo method uses the Comparable compareTo Method to return 1, 0, or -1 to determine the relationship of the perimeters.

* If I wanted to make it so that Problem1 prints out all the rectangles of the same perimeter, I would have to rewrite the findMax method,
so it takes equal perimeter rectangles into account.
* There is no user input required.

Problem2.java
    For the main method I hard coded some rectangles and performed a binary search on the array of rectangles
    For the binarySearch Method, it is a driver method to start the recursive method (helper method) search.
    The search method is a helper method that returns either 1,0,-1 depending on whether the values match.
    The methods only return expected outputs if the array is in order.

Problem3.java
    I made seperate methods for each code fragment
    Then for the main method I iterated over set values of i and stored the results of the time Elapse in a seperate Array
    Then I printed out these values into a seperate text file and added new lines so it is easier on the eyes.
    In order to make sure I was evaluating the functions appropriately I stored a set of values in their own array