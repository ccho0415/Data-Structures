//-------------------------------
// Christine Chong cc4190
// Problem3.java
// Finding RunTimes of Code Snippets
//-------------------------------
// Importing Packages
import java.io.*;

public class Problem3{

    // First Fragment     
    public static int bar(int n){
        int sum = 0;
        for ( int i = 0; i < 23; i ++)
            for ( int j = 0; j < n ; j ++)
                sum = sum + 1;  
        return sum;
    }
    
    // Second Fragment     
    public static int baz(int n){
        int sum = 0;
        for ( int i = 0; i < n ; i ++)
            for ( int k = i ; k < n ; k ++)
                sum = sum + 1; 
        return sum;
    }
    
    //Third Fragment     
    public static int foo(int n, int k) {
        if(n<=k)
            return 1;
        else
            return foo(n/k,k) + 1;
    }    
        
    // Main Method to Run these Functions and to output the Time Elapse     
    public static void main (String[] args) throws FileNotFoundException{
        int k = 2;       
        long[] times = new long[9];
        int[] vals = {30, 300, 30000, 30, 300, 30000, 30, 300, 30000};
        for(int i=0; i<3; i++){
            long starTime = System.currentTimeMillis();
            System.out.println(" "+foo(vals[i], k));
            long endTime = System.currentTimeMillis();
            long timeElapse = endTime - starTime;
            times[i] = timeElapse;    
        }
        for(int i=3; i<6; i++){
            long starTime = System.currentTimeMillis();
            System.out.println(" "+bar(vals[i]));
            long endTime = System.currentTimeMillis();
            long timeElapse = endTime - starTime;
            times[i] = timeElapse;    
        }        
        
        for(int i=6; i<9; i++){
            long starTime = System.currentTimeMillis();
            System.out.println(" "+baz(vals[i]));
            long endTime = System.currentTimeMillis();
            long timeElapse = endTime - starTime;
            times[i] = timeElapse;                
        }        
	    PrintWriter output = new PrintWriter("output.txt");
        for(int i=0; i <times.length; i++){
                if(i == 2 || i == 5 ){
	                long time=times[i];
	                output.println(time);                     
                    output.println("\n");                    
                }else{
	                long time=times[i];
	                output.println(time);                    
                }

	    }
	    output.close();
 	    for(int i=0; i<times.length; i++){
            System.out.println(""+times[i]);
        }
        
	}    
    
}