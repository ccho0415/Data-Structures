//-------------------------------
// Christine Chong cc4190
// MyStack.java
// This is a generic Stack Class Made from Array Lists
//-------------------------------
import java.util.*;
public class MyStack<AnyType>{
    private LinkedList<AnyType> stack;
    public MyStack(){
        stack = new LinkedList<AnyType>();  
    }
    public AnyType push(AnyType element){
        stack.add(0, element);
        return element;
    }
    public AnyType pop() throws EmptyException{
        if(stack.size() == 0){
            EmptyException e = new EmptyException("There is no more to pop.");
            throw e;
        }else{
            return stack.remove(0);
        }
    }
    public AnyType peek(){
        if(stack.isEmpty()){
            EmptyException e = new EmptyException("The stack is empty");
            throw e;
        }else{
            return stack.get(0);
        }
    }
    public Boolean isEmpty(){
        return stack.size() == 0;
    }
    public void print(){
        System.out.println(""+stack);
    }
    public int size(){
        if(stack.size() == 0 ){
            return 0;
        }else{
            return stack.size();   
        }

    }
    public AnyType search(int i){
        return stack.get(i);
    }
}