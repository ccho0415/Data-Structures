//-------------------------------
// Christine Chong cc4190
// TwoStackQueueTester.java
// A class to test TwoQueue.
//-------------------------------
public class TwoStackQueueTester {
    public static final void main(String[] args) {
        TwoQueue<String> q  = new TwoQueue<String>();
        System.out.println(q.size());
        q.enqueue("Peter");
        q.enqueue("Paul");
        q.enqueue("Mary");
        System.out.println(q.dequeue());
        System.out.println(q.size());
        q.enqueue("Simon");
        q.enqueue("Alvin");
        System.out.println(q.dequeue());
        q.enqueue("Theodore");
        while(!q.isEmpty())    
            System.out.println(q.dequeue());
    }
}