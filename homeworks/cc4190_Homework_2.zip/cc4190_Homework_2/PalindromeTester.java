//-------------------------------
// Christine Chong cc4190
// PalidromeTester.java
// A class to determine if something is a palindrome
//-------------------------------
import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;
import java.io.*;
public class PalindromeTester {
    //Main Method
    public static void main(String[] args) {
        //Try Catch Block For Exceptions
        try{
            File inFile = new File("palindromes.txt");
            Scanner input = new Scanner(inFile);
            while(input.hasNext()) {
           	    String current = input.nextLine();                
		        String extract = current.replaceAll("[^a-zA-Z]+", "");
                extract = extract.toUpperCase();
                ArrayList<Character> c = new ArrayList();
                MyStack s = new MyStack();
                add(extract , s, c);
		        if(palindrome(s,c)) {
		        	System.out.println(extract +" is a palindrome");
		        }else {
		        	System.out.println(extract +" is not a palindrome");
		        }        
            }
            }catch(EmptyException e){
                System.out.print(e.getMessage());
            }catch(FileNotFoundException r){
                System.out.println("Please put in palindromes.txt in your directory");
            }

		}

		public static void add(String str, MyStack s, ArrayList<Character> c) {
			//Adding to the stack and the comparision array list
            int max = str.length();
            int mid = max/2;
			for(int i=0; i < mid; i++) {
				s.push(str.charAt(i)); 
			}            
            if(max%2 == 0){
               for(int i=mid; i<max; i++){
                    c.add(str.charAt(i));   
               }
            }else{
               for(int i=mid+1; i<max; i++){
                    c.add(str.charAt(i));   
               }
            }

		}
		
		public static boolean palindrome(MyStack s, ArrayList<Character> c) {
			// Pop and compare
            int max = c.size();
			for(int i=0; i<max; i++) {
				char val = (char)s.pop();
				if (val != c.get(i) ) {
					return false;
				}
			}
			return true;
		}

}