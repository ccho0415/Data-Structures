//-------------------------------
// Christine Chong cc4190
// TwoQueue.java
// A class to handle the queue functions for the stacks
//-------------------------------
public class TwoQueue<AnyType> implements MyQueue<AnyType>{
    MyStack s1 ;
    MyStack s2 ;
    public TwoQueue(){
        s1 = new MyStack();
        s2 = new MyStack();        
    }
    public void enqueue(AnyType x){
        s1.push(x);
    }
    public AnyType dequeue()throws EmptyException{
        int max1 = s1.size();
        AnyType x = (AnyType) s1.peek();
        AnyType y;
        for(int i=0; i < max1; i++){           
            x = (AnyType) s1.pop();
            s2.push(x);        
        } 
        AnyType val = (AnyType) s2.pop();
        int max2 = s2.size();
        for(int i=0; i < max2; i++){
            y = (AnyType) s2.pop();
            s1.push(y);
        }
        return val ;            

    }
    public boolean isEmpty(){
        return s1.size() == 0 && s2.size() ==0;        
    }
    public int size(){
      return s1.size() + s2.size();
    }
}