public class EmptyException extends IllegalArgumentException{
    public EmptyException(){
        super();
    }
    public EmptyException(String message){
        super(message);
    }
}