### Palindrome Function
    How it works:
        Have palindromes.txt in the same directory.
        Run the program.
    Limitations:
        It will only work if all the letters are uppercase. This can be very hard to read.
    External Classes Used:
        Linked List
        List
        Scanner
        IllegalArgumentException
        MyStack
### TwoQueue Stack
    How it works:
        Run the program
    Limitations:
        For some reason it prints out a [] at the end.
    External Classes Used  
        Linked List
        List
        IllegalArgumentException
        MyStack