//-------------------------------
// Christine Chong cc4190
// MyQueue.java
// An interface for the queue stacks
//-------------------------------
public interface MyQueue<AnyType> {

    public void enqueue(AnyType x);
    public AnyType dequeue();
    public boolean isEmpty();
    public int size();
}
   