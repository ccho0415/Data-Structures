import java.util.PriorityQueue;
import java.util.List;
import java.util.ArrayList;
import java.util.*;
import java.util.Arrays;
public class KBestCounter<T extends Comparable<? super T>> {

    PriorityQueue<T> heap;
    int k;
    
    public KBestCounter(int k) {
        heap = new PriorityQueue<T>();  
        Iterator<T> itr=heap.iterator();         
        this.k = k;
    }

    public void count(T x) {
        heap.offer(x);
    }

    public List<T> kbest() {
        List<T> result = new ArrayList();
        List<T> addback = new ArrayList(5);
    
        T largest = heap.poll(); 
           
            while(heap.peek() != null){ 
                T n = heap.poll();    
//                 System.out.println("Largest : "+largest); 
//                 System.out.println("N: "+n); 
//                 System.out.println("Compare "+ n.compareTo(largest));
//                 if(n!= null){
                    if(n.compareTo(largest)>0 ){
                        heap.add(largest);  
                        largest = n;
                        heap.remove(largest); 
//                         System.out.println("Peek "+ heap.peek() );
                    }
                    if(n.compareTo(largest) == -1){
                        heap.remove(n);
                        addback.add(n); 
//                         System.out.println("Peek 2 "+ heap.peek() );
                    }
//                 }
            }
        
            result.add(largest);
//             System.out.println("Add BACK: "+addback.size());
            int max = addback.size()-1;
        

            if(max<5){
            for(int i=max; i>=0; i--){
               T num =addback.get(i);
//                 System.out.println("NUM: "+num);
                result.add(num);
            }                 
            }else{
            for(int i=max; i>=max-3; i--){
               T num =addback.get(i);
//                 System.out.println("NUM: "+num);
                result.add(num);
            }                 
            }
           
        

 
       
        for(int i=0; i< result.size();i++){
            heap.add(result.get(i));
        }
        
        return result;
    }
    

}
