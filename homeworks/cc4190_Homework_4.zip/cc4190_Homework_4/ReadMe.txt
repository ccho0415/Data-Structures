Spell Checker
How to use:
    java SpellChecker dictionaryFile yourFile\
Known Errors :
    Words that are put in between '' will be caught
    If there are empty lines in between words, the program will end (this is intentionally put it so as to not deal with an exception)
Comments:
    Used RegEx to remove punctuations and .toLowerCase()
    Used .trim() to get rid of excess space
    Very minimally used Weiss' code for the Node
    Used Hash Sets
 
K Best

I am pretty sure that the big O cost is incorrect.
 