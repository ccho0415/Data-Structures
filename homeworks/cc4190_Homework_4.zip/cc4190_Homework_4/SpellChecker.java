//-------------------------------
// Christine Chong cc4190
// SpellChecker.java
// A class to check for misspelt words
// and suggest other spellings
// Modified Weiss' AVLNode code
//-------------------------------

import java.util.Scanner;
import java.io.*;
import java.util.HashSet;
import java.util.Iterator;
public class SpellChecker{
    //Globals
    private static String stringInput;
    private static String[] checkThis;
    private static HashSet dictionary;
    private static HashSet userInput;
    
    //Constructor
    public SpellChecker(String dict, String userIn){
        final int initSize = 991;
        dictionary = new HashSet(initSize);
        userInput = new HashSet(initSize);
        //Try Catch Block for File Exception
        try{
            File d = new File(dict);
            Scanner dictScan = new Scanner(d);
            // Dictionary Hash Set Create
            while(dictScan.hasNextLine()){
                String current = dictScan.nextLine().trim();
                dictionary.add(current.replaceAll("[^a-zA-Z\\']", "").toLowerCase());
            }
            int line = 0;
            File user = new File(userIn);
            Scanner userScan = new Scanner(user);
           //User Input Hash Set Create
            while(userScan.hasNextLine()){
                line++;
                String current = userScan.nextLine().trim();
                if (current.equals("")){
                    break;
                }
                String[] words = current.replaceAll("[^a-zA-Z\\'\\s+]", "").toLowerCase().split("\\s+");
                for(int i=0; i < words.length; i++){
                    Node n = new Node(words[i], line);
                    if(check(words[i]) == false){
                        userInput.add(n); 
                        System.out.println("Word : " + n.word +" \nLine Number : "+ n.line);                        
                        fix(words[i]);
                    }    
                }
            }
            
// This checks if everything has been inputted in properly            
//             Iterator itr = userInput.iterator();
//                 while(itr.hasNext()){
//                     Node x = (Node)itr.next();
//                     System.out.println("Word : " + x.word +" \nLine Number : "+ x.line);
//                 }
            
        }
        catch(FileNotFoundException e){
            System.out.println("Cannot find file");
        }
    }
    //Checks with dictionary Hash Set
    public boolean check(String word){
        if(dictionary.contains(word)){
            return true;
        }else{
            return false;
        }
    }
    //Runs Different Fix Methods
    public void fix(String word){
        System.out.println("Did you perhaps mean this word ?");
        System.out.println(""+append(word)+" or");
        System.out.println(""+remove(word)+" or");
        System.out.println(""+swap(word));
        System.out.println("");
    }
    //Fix By Appending
    public String append(String word){
        char c;
        String tempWord = "";
        for(int i=97; i<123; i++){
            c = (char)i;
            tempWord = word.substring(0, word.length())+c;
            if(dictionary.contains(tempWord)){
                return(tempWord);
            }
            tempWord = "";
        }
        return "Not able to fix by appending";

    }
    //Fix by Removing
    public String remove(String word){
        String tempWord = "";
        tempWord = word.substring(0,word.length()-1);
        if(dictionary.contains(tempWord)){
            return(tempWord);
        }
        tempWord = word.substring(1,word.length());
        if(dictionary.contains(tempWord)){
            return(tempWord);
        }                
        return "Not able to fix by removing the first or last letter";

    }    
    //Fix by Swapping
    public String swap(String word){
        String tempWord = "";
        for(int i =0; i< word.length() -1 ; i++){
            tempWord = word.substring(0,i)
                       + word.charAt(i+1)
                       + word.charAt(i)
                       + word.substring(i+2);
            if(dictionary.contains(tempWord)){
                return(tempWord);
            }                
            
        }
        return "Not able to fix by swapping";
    }
    //Weiss Modified AVL Node into generic Node
    private static class Node
    {
        Node( String word, int line  )
        {
           this.word = word;
            this.line = line;
        }

        String word;
        int line;
    } 
    
    //Main
    public static void main(String[] args){
        String dict = args[0];
        String user = args[1];
        SpellChecker s = new SpellChecker(dict, user);
    }
}