//-------------------------------
// Christine Chong cc4190
// ExpressionTree.java
// A class that creates Expression 
// Trees, evaluates postfix expressions,
// and traverses through the tree using
// postfix Ordinger, prefix Ordering 
// and infix Ordering.
//-------------------------------
import java.util.Stack;
public class ExpressionTree{
    
//  private global variables
    private final String postfix;
    private TreeNode root;

//  Information about the root    
    public TreeNode getRoot(){
        return root;
    }

//  Constructor    
    public ExpressionTree(String postfix) {
        this.postfix = postfix;
        root = null;
    }        

//  Nested class for Tree Nodes    
    private static class TreeNode{
        public TreeNode left = null;
        public String c;
        public TreeNode right = null;
        
        TreeNode(String c){
            this.c = c;
        }
        public String print(){
            return c;
        }
    }
     
 
//  Check for Operators    
    private boolean isOperator(String c){
//         System.out.println(c+" ");
//         System.out.println(c.equals( "+") || c.equals( "-")|| c.equals( "x") || c.equals( "/"));
        return c.equals( "+") || c.equals( "-")|| c.equals( "x") || c.equals( "/");
    }
    
//  Creates the Binary Search Tree    
    public void insert(String[] s){
        Stack<TreeNode> stack = new Stack<TreeNode>();
        for(int i=0; i < s.length; i++){       
//             System.out.println(s[i]+" ");
            if(isOperator(s[i]) == false){
                TreeNode n = new TreeNode(s[i]);
//                 System.out.println(n.print());
                stack.push(n);
            }else{
                TreeNode n2 = stack.pop();
//                 System.out.println("N2 : "+ n2.print());
                TreeNode n1 = stack.pop();
//                 System.out.println("N1 : "+ n1.print());                
                TreeNode sym = new TreeNode(s[i]);
                sym.left = n1;
                sym.right = n2;
                stack.push(sym);   
                TreeNode n3 = sym.left;
                TreeNode n4 = sym.right;
//                 System.out.println("Left : "+n3.print());
//                 System.out.println("Right : "+n4.print());
//                 System.out.println("Sym : "+sym.print());                
            }            
        }
        root = stack.peek();

    }

//  Numerically evaluates the Post Fix Expression Using Stacks    
    public Integer eval(String[] s){
        Stack<Integer> stack = new Stack<Integer>();
        for (int i=0; i < s.length; i++){
//             System.out.print(s[i]+" ");
            if(isOperator(s[i]) == false){
                int n = Integer.parseInt(s[i]);
                stack.push(n);
            }else{
                String sym = s[i];
                int n2 = stack.pop();
                int n1 = stack.pop();
                int r;
                // Switch Block for the operator
                switch(sym){
                    case "+" : r = n1 + n2; break;
                    case "-" : r = n1 - n2; break;
                    case "/" : r = n1 / n2; break;
                    case "x" : r = n1 * n2; break;   
                    default :  r = n1 + n2; break;  
                }
                stack.push(r);
            }
        }
        return stack.pop();
    } 

//  Post Order Traversal
    public String postOrder(TreeNode n){
        String s = "";
        if(n != null){
            // Children first then Parent
            s = s+postOrder(n.left); 
            s = s+postOrder(n.right); 
            s = s+n.c+" ";
        }
        return s;        
    }

//  Pre Order Traversal    
    public String preOrder(TreeNode n){
        String s = "";
        if(n != null){
            // Parent first then Children
            s = s+n.c+" ";             
            s = s+preOrder(n.left);            
            s = s+preOrder(n.right); 

        }
        return s;           
        
    }

// In Order Traversal    
    public String inOrder(TreeNode n){
        String s = "";
        if(n != null){ 
            // Going In order. There are excessive parenthesis
            s = s + "(";
            s = s+inOrder(n.left);
            s = s+n.c+" ";             
            s = s+inOrder(n.right); 
            s = s + ")";
        }
        return s;  
        
    }

}