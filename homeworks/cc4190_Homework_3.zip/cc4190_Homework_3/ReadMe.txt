Expression Tree:

    If you want to use the command line option:

    There is a code block to uncomment in Problem1.java.
    Remember to comment out the hard coded Expressions.
    
    Possible Deviations from Instructions:
        2 Stacks
            1. Evaluate Stack
            2. Build Tree Stack
        
        Switch Block
            This makes evaluating easier.
        
        Using Regex
    
    Comments:
        While I think the parenthesis are excessive, they should be correct.

Problem 1:
    Main Method for Expression Tree.
---------------------------------------------------------------------------------------------------------------
Problem 2:
    Used Palindrome Tester as a base for processing the word file.
    Everything prints out into seperate lines.
    
AvlTree:
    Added changeLine function.
    added line requirement for the AVL Node.
    Removed the remove function.
    Removed the main class.