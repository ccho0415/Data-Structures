//-------------------------------
// Christine Chong cc4190
// ExpressionTree.java
// A class to test the Expression
// Tree class
//-------------------------------
import java.io.*;
public class Problem1{

    public static void main (String[] args){
        
//  If you want to use the terminal command line instead uncomment this and comment out the hard coded postfix expressions a
//  Use x instead of * for multiplication.
//         
//         String postfix = "";
//         for(int i=0; i< args.length; i++){
//             postfix = postfix + args[i]+" ";             
//         }

//      Test One   
        String postfix = "4 9 + 3 5 x -";     
        ExpressionTree a = new ExpressionTree(postfix); 
        String[] s = postfix.split("\\s+");
        a.insert(s);
        System.out.println(a.eval(s)+"");
        System.out.println(""+a.postOrder(a.getRoot()));
        System.out.println(""+a.preOrder(a.getRoot()));
        System.out.println(""+a.inOrder(a.getRoot()));

//      Test Two           
        String postfix2 = "2 3 1 x + 9 -";     
        ExpressionTree b = new ExpressionTree(postfix2); 
        String[] t = postfix2.split("\\s+");
        b.insert(t);
        System.out.println(b.eval(t)+"");
        System.out.println(""+b.postOrder(b.getRoot()));
        System.out.println(""+b.preOrder(b.getRoot()));
        System.out.println(""+b.inOrder(b.getRoot()));  

//      Test Three           
        String postfix3 = "10 2 8 x + 3 -";     
        ExpressionTree c = new ExpressionTree(postfix3); 
        String[] u = postfix3.split("\\s+");
        a.insert(u);
        System.out.println(c.eval(u)+"");
        System.out.println(""+c.postOrder(c.getRoot()));
        System.out.println(""+c.preOrder(c.getRoot()));
        System.out.println(""+c.inOrder(c.getRoot()));        
    }
}