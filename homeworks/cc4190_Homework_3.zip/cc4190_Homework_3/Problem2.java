//-------------------------------
// Christine Chong cc4190
// Problem 2.java
// A class to turn a text file of words
// into an AVL Tree. Using Weiss'
// AVL Tree class.
//-------------------------------
import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;
import java.io.*;
public class Problem2 {
    //Main Method
    public static void main(String[] args) {
        //Try Catch Block For Exceptions
        try{
            int line = 0;
            File inFile = new File(args[0]);
            Scanner input = new Scanner(inFile);
            AvlTree a = new AvlTree();
            while(input.hasNextLine()) {
                line ++;
           	    String current = input.nextLine();  
                //Regex for punctuation also making sure every letter is lowercase 
                //(this allows for better comparisions)
		        String[] words = current.replaceAll("[^a-zA-Z ]", "").toLowerCase().split("\\s+");  
                for (int i=0; i< words.length; i ++){
                    if(a.contains(words[i])){
                        a.changeLine(words[i],line);
                    }else{
                       a.insert(words[i], line);
                    }
                }
                current = "";
                words = null;
            }
            a.printTree();
            }catch(FileNotFoundException r){
                System.out.println("Please put in a .txt in your directory");
            }

		}

}